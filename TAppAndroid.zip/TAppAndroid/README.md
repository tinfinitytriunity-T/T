# TAppAndroid (minimal)

This is a minimal Android (Kotlin + Jetpack Compose) project meant to be built via GitHub Actions to produce a debug APK.

## Build
- `./gradlew assembleDebug`

The APK will be at:
- `app/build/outputs/apk/debug/app-debug.apk`
