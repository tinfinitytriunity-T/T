package com.example.tapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.*
import kotlin.math.hypot
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TApp() }
    }
}

@Composable
private fun TApp() {
    val ctx = LocalContext.current

    // Volatile only
    var text by remember { mutableStateOf("") }
    var density by remember { mutableStateOf(DensityHint.NEUTRAL) }
    var breath by remember { mutableStateOf(BreathPhase.NORMAL) }
    var eText by remember { mutableStateOf<String?>(null) }

    // Auto-retenue (RAM only)
    var fog by remember { mutableIntStateOf(0) }
    val availability = (1f - fog * 0.12f).coerceIn(0.15f, 1f)

    // “Enter” each time content changes: local impressions, not metrics
    fun reenter() {
        fog = (fog + 1).coerceAtMost(6)
        density = listOf(DensityHint.LIGHT, DensityHint.NEUTRAL, DensityHint.DENSE).random()
        breath = listOf(BreathPhase.SLOW, BreathPhase.NORMAL, BreathPhase.TIGHT).random()
        eText = maybeEmitE(rarity = 40 + fog * 40, allow = fog <= 3)
    }

    LaunchedEffect(Unit) { reenter() }

    DisposableEffect(Unit) {
        onDispose {
            // Dissolve everything
            text = ""
            density = DensityHint.NEUTRAL
            breath = BreathPhase.NORMAL
            eText = null
            fog = 0
        }
    }

    val breathDuration = when (breath) {
        BreathPhase.SLOW -> 16000
        BreathPhase.NORMAL -> 12000
        BreathPhase.TIGHT -> 8000
    }

    val infinite = rememberInfiniteTransition(label = "breath")
    val t by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(breathDuration, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "t"
    )

    val grainAlpha = when (density) {
        DensityHint.LIGHT -> 0.03f
        DensityHint.NEUTRAL -> 0.06f
        DensityHint.DENSE -> 0.10f
    } * availability

    val bgBrush = Brush.radialGradient(
        colors = listOf(
            Color(0xFF0B0B10),
            Color(0xFF101022),
            Color(0xFF07070A)
        ),
        center = Offset(
            x = 200f + 800f * t,
            y = 400f + 600f * (1f - t)
        ),
        radius = 1100f
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgBrush)
            .pointerInput(Unit) {
                detectTwoFingerLongPress(
                    longPressMs = (1500 + fog * 250).toLong(),
                    onLongPress = {
                        // Césure: local, non explicative
                        val next = cut(text)
                        text = next
                        // Tighten impression a bit
                        density = when (density) {
                            DensityHint.LIGHT -> DensityHint.NEUTRAL
                            DensityHint.NEUTRAL -> DensityHint.DENSE
                            DensityHint.DENSE -> DensityHint.DENSE
                        }
                        breath = when (breath) {
                            BreathPhase.SLOW -> BreathPhase.NORMAL
                            BreathPhase.NORMAL -> BreathPhase.TIGHT
                            BreathPhase.TIGHT -> BreathPhase.TIGHT
                        }
                        eText = null
                    }
                )
            }
            .pointerInput(Unit) {
                detectTripleTapTopRight(
                    cornerSizeDp = 72.dp,
                    onTrigger = {
                        shareText(ctx, text.ifBlank { "—" })
                    }
                )
            }
            .padding(horizontal = 20.dp, vertical = 26.dp)
    ) {
        // Grain
        Box(
            modifier = Modifier
                .fillMaxSize()
                .alpha(grainAlpha)
                .background(
                    Brush.linearGradient(
                        listOf(Color.White, Color.Transparent, Color.White),
                        start = Offset(0f, 0f),
                        end = Offset(1200f, 2400f)
                    )
                )
        )

        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            if (!eText.isNullOrBlank()) {
                androidx.compose.material3.Text(
                    text = eText!!,
                    modifier = Modifier.alpha(0.55f * availability),
                    color = Color(0xFFE9E9F2),
                    fontSize = 14.sp
                )
            } else {
                Spacer(Modifier.height(18.dp))
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .alpha(availability)
            ) {
                BasicTextField(
                    value = text,
                    onValueChange = {
                        text = it
                        reenter()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.CenterStart),
                    textStyle = TextStyle(
                        color = Color(0xFFE9E9F2),
                        fontSize = 18.sp,
                        lineHeight = 26.sp
                    ),
                    cursorBrush = SolidColor(Color.Transparent)
                )
            }

            Spacer(Modifier.height(10.dp))
        }
    }
}

// --- Model (qualitative hints, not metrics)
private enum class DensityHint { LIGHT, NEUTRAL, DENSE }
private enum class BreathPhase { SLOW, NORMAL, TIGHT }

// --- E^ (rare)
private fun maybeEmitE(rarity: Int, allow: Boolean): String? {
    if (!allow) return null
    if (Random.nextInt(rarity.coerceAtLeast(10)) != 0) return null
    return listOf(
        "Ce n’est pas ici.",
        "Laisse.",
        "Rien n’est requis.",
        "—",
        "Tu peux sortir."
    ).random()
}

// --- Cut (local, reversible only by quitting)
private fun cut(text: String): String {
    if (text.isBlank()) return ""
    return when (Random.nextInt(4)) {
        0 -> fragment(text)
        1 -> extremeSpacing(text)
        2 -> partialDrop(text)
        else -> "" // dissolution
    }
}

private fun fragment(text: String): String {
    val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
    if (words.size <= 2) return text.toCharArray().joinToString(" ")
    return words.filterIndexed { i, _ -> i % 2 == 0 }.joinToString(" ")
}

private fun extremeSpacing(text: String): String =
    text.toCharArray().joinToString("   ")

private fun partialDrop(text: String): String {
    val cut = (text.length * (0.35 + Random.nextDouble() * 0.25)).toInt().coerceIn(1, text.length)
    return text.dropLast(cut)
}

// --- Share
private fun shareText(context: android.content.Context, text: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(intent, null))
}

// --- Gestures
private suspend fun PointerInputScope.detectTripleTapTopRight(
    cornerSizeDp: Dp,
    onTrigger: () -> Unit
) {
    val cornerSizePx = with(LocalDensity.current) { cornerSizeDp.toPx() }
    var taps = 0
    var lastTapTime = 0L

    awaitEachGesture {
        val down = awaitFirstDown()
        val now = System.currentTimeMillis()

        val inTopRight = down.position.x >= size.width - cornerSizePx && down.position.y <= cornerSizePx
        if (!inTopRight) {
            taps = 0
            return@awaitEachGesture
        }

        if (now - lastTapTime > 700) taps = 0
        taps += 1
        lastTapTime = now

        waitForUpOrCancellation()

        if (taps >= 3) {
            taps = 0
            onTrigger()
        }
    }
}

private suspend fun PointerInputScope.detectTwoFingerLongPress(
    longPressMs: Long,
    onLongPress: () -> Unit
) {
    awaitEachGesture {
        val first = awaitFirstDown()
        var secondId: PointerId? = null

        // Wait for second finger
        while (secondId == null) {
            val event = awaitPointerEvent()
            val pressed = event.changes.filter { it.pressed }
            if (pressed.size >= 2) {
                secondId = pressed[1].id
                break
            }
            if (!event.changes.any { it.id == first.id && it.pressed }) return@awaitEachGesture
        }

        var startTime = System.currentTimeMillis()
        var triggered = false

        var p1Start = first.position
        var p2Start = p1Start
        run {
            val event = awaitPointerEvent()
            event.changes.firstOrNull { it.id == secondId }?.let { p2Start = it.position }
        }

        while (true) {
            val event = awaitPointerEvent()
            val c1 = event.changes.firstOrNull { it.id == first.id } ?: return@awaitEachGesture
            val c2 = event.changes.firstOrNull { it.id == secondId } ?: return@awaitEachGesture

            if (!c1.pressed || !c2.pressed) return@awaitEachGesture

            val moved1 = hypot((c1.position.x - p1Start.x).toDouble(), (c1.position.y - p1Start.y).toDouble()) > 24.0
            val moved2 = hypot((c2.position.x - p2Start.x).toDouble(), (c2.position.y - p2Start.y).toDouble()) > 24.0
            if (moved1 || moved2) return@awaitEachGesture

            if (!triggered && System.currentTimeMillis() - startTime >= longPressMs) {
                triggered = true
                onLongPress()
                return@awaitEachGesture
            }
        }
    }
}
